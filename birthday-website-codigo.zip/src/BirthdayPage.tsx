import { useState, useEffect } from "react";
import MusicPlayer from "./components/MusicPlayer";
import CardModal from "./components/CardModal";
import AdventCalendar from "./components/AdventCalendar";
import PhotoStrip from "./components/PhotoStrip";
import {
  BIRTHDAY_PERSON,
  TAGLINE,
  FOOTER_TEXT,
  CARDS,
  BIRTHDAY_DATE,
  PHOTOS,
  QUOTES,
} from "./config";

// ── date helpers ────────────────────────────────────────────
function today() {
  const d = new Date();
  return { month: d.getMonth() + 1, day: d.getDate() };
}
function isUnlocked(m: number, d: number) {
  const t = today();
  if (t.month > m) return true;
  if (t.month < m) return false;
  return t.day >= d;
}
function isBirthday() {
  const t = today();
  return t.month === BIRTHDAY_DATE.month && t.day === BIRTHDAY_DATE.day;
}
function nextUnlock() {
  const t = today();
  const all = [
    { month: 6, day: 15 }, { month: 6, day: 16 }, { month: 6, day: 17 },
    { month: 6, day: 18 }, { month: 6, day: 19 }, { month: 6, day: 20 },
  ];
  return all.find(c => t.month < c.month || (t.month === c.month && t.day < c.day)) ?? null;
}

function useCountdown(m: number, d: number) {
  const [diff, setDiff] = useState(0);
  useEffect(() => {
    const calc = () => {
      const now = new Date();
      let target = new Date(now.getFullYear(), m - 1, d);
      if (target <= now) target = new Date(now.getFullYear() + 1, m - 1, d);
      setDiff(Math.max(0, target.getTime() - now.getTime()));
    };
    calc();
    const id = setInterval(calc, 1000);
    return () => clearInterval(id);
  }, [m, d]);
  const s = Math.floor(diff / 1000);
  return {
    days:  Math.floor(s / 86400),
    hours: Math.floor((s % 86400) / 3600),
    mins:  Math.floor((s % 3600) / 60),
    secs:  s % 60,
  };
}

const f2 = (n: number) => String(n).padStart(2, "0");

// ── component ───────────────────────────────────────────────
export default function BirthdayPage() {
  const [selectedCard, setSelectedCard] = useState<(typeof CARDS)[0] | null>(null);
  const [view, setView] = useState<"cards" | "memories">("cards");
  const birthday = isBirthday();
  const next      = nextUnlock();
  const cd        = useCountdown(next?.month ?? 6, next?.day ?? 18);

  // photos for the book page
  const heartPhoto  = PHOTOS[0] ?? null;   // main heart photo
  const polaroid1   = PHOTOS[1] ?? null;
  const polaroid2   = PHOTOS[2] ?? null;

  return (
    <div className="page-root">

      {/* ── TOP RIGHT ICONS ── */}
      <div className="top-icons">
        <span className="tbicon">♪</span>
        <span className="tbicon">🔊</span>
      </div>

      {/* ── MAIN LAYOUT: left panel + book ── */}
      <div className="site-layout">

        {/* ═══ LEFT PANEL (outside the book) ═══ */}
        <div className="left-panel">

          {/* Title in top-left corner */}
          <div className="lp-title-block">
            <span className="lp-heart">♥</span>
            <div className="lp-title-text">
              <span className="lp-t1">Happy</span>
              <span className="lp-t2">Birthday</span>
              <span className="lp-t3">{BIRTHDAY_PERSON}!</span>
            </div>
            <span className="lp-heart">♥</span>
          </div>

          {/* Tagline */}
          <div className="lp-tagline">
            <span className="lp-tagline-note">♪</span>
            <p>{TAGLINE}</p>
          </div>

          {/* Music player */}
          <MusicPlayer />

          {/* Countdown */}
          {!birthday && next && (
            <div className="lp-countdown">
              <div className="lp-cd-label">PRÓXIMA CARTA</div>
              <div className="lp-cd-row">
                <div className="lp-cd-tile"><span>{f2(cd.days)}</span><label>DIAS</label></div>
                <div className="lp-cd-tile"><span>{f2(cd.hours)}</span><label>HORAS</label></div>
                <div className="lp-cd-tile"><span>{f2(cd.mins)}</span><label>MIN</label></div>
                <div className="lp-cd-tile"><span>{f2(cd.secs)}</span><label>SEG</label></div>
              </div>
              <div className="lp-cd-sub">será aberta em {next.month}/{next.day}</div>
            </div>
          )}

          {/* Nav buttons */}
          <div className="lp-nav">
            <button
              className={`lp-navbtn ${view === "memories" ? "lp-navbtn-active" : ""}`}
              onClick={() => setView("memories")}
            >
              <span className="lp-navicon">☆</span>
              <span>Memórias</span>
            </button>
            <button
              className={`lp-navbtn ${view === "cards" ? "lp-navbtn-active" : ""}`}
              onClick={() => setView("cards")}
            >
              <span className="lp-navicon">✉</span>
              <span>Cartas</span>
            </button>
          </div>

          <p className="lp-footer">{FOOTER_TEXT}</p>
        </div>

        {/* ═══ BOOK ═══ */}
        <div className="book">

          {/* ── LEFT PAGE (burlap) ── */}
          <div className="page-left">

            {/* Decorative stickers scattered on the page */}
            <span className="sticker s-flower-tl">✿</span>
            <span className="sticker s-heart-tr">♥</span>
            <span className="sticker s-rose">🌹</span>
            <span className="sticker s-sparkle1">✦</span>
            <span className="sticker s-sparkle2">✧</span>
            <span className="sticker s-heart2">♡</span>
            <span className="sticker s-flower-br">❀</span>
            <span className="sticker s-bear">🧸</span>
            <span className="sticker s-puzzle">🧩</span>
            <span className="sticker s-flower2">🌸</span>

            {/* Top quote */}
            <p className="book-quote bq-top">{QUOTES[0]}</p>

            {/* Heart photo */}
            <div className="heart-frame-wrap">
              <div className="heart-frame">
                {heartPhoto ? (
                  <img src={heartPhoto} alt="Main" className="heart-img" />
                ) : (
                  <div className="heart-ph">
                    <span>📷</span>
                    <small>public/photos/photo1.jpg</small>
                  </div>
                )}
              </div>
              {/* sparkle corners */}
              <span className="hf-spark hf-spark-tl">✦</span>
              <span className="hf-spark hf-spark-tr">✦</span>
              <span className="hf-spark hf-spark-bl">✧</span>
              <span className="hf-spark hf-spark-br">✦</span>
            </div>

            {/* Mid quote */}
            <p className="book-quote bq-mid">{QUOTES[1]}</p>

            {/* Polaroids */}
            <div className="polaroids-row">
              <div className="polaroid pol-l">
                {polaroid1 ? (
                  <img src={polaroid1} alt="Photo 2" />
                ) : (
                  <div className="pol-ph">📷<br/><small>photo2.jpg</small></div>
                )}
                <div className="pol-label">{QUOTES[2]}</div>
              </div>
              <div className="polaroid pol-r">
                {polaroid2 ? (
                  <img src={polaroid2} alt="Photo 3" />
                ) : (
                  <div className="pol-ph">📷<br/><small>photo3.jpg</small></div>
                )}
                <div className="pol-label">você e eu, sempre.</div>
              </div>
              <p className="pol-caption">meu lugar favorito ♡</p>
            </div>

            {/* Lace border */}
            <div className="lace-border">
              {Array.from({ length: 22 }).map((_, i) => (
                <div key={i} className="lace-loop" />
              ))}
            </div>
          </div>

          {/* ── SPINE ── */}
          <div className="spine">
            {Array.from({ length: 24 }).map((_, i) => (
              <div key={i} className="ring" />
            ))}
          </div>

          {/* ── RIGHT PAGE ── */}
          <div className="page-right">
            {birthday ? (
              <AdventCalendar />
            ) : view === "memories" ? (
              <div className="memories-view">
                <h2 className="right-header">Nossas Memórias ♡</h2>
                <div className="memories-grid">
                  {PHOTOS.map((src, i) => (
                    <div key={i} className="mem-thumb">
                      <img src={src} alt={`Memory ${i + 1}`} />
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <>
                <h2 className="right-header">
                  Cartas para abrir<br />nos nossos dias especiais ♡
                </h2>

                {/* Decorative clip */}
                <div className="paper-clip" />

                <div className="cards-list">
                  {CARDS.map((card) => {
                    const unlocked = isUnlocked(card.unlockMonth, card.unlockDay);
                    const isToday  =
                      today().month === card.unlockMonth &&
                      today().day   === card.unlockDay;
                    return (
                      <div
                        key={card.id}
                        className={`card-row ${unlocked ? "card-open" : "card-locked"}`}
                        onClick={() => unlocked && setSelectedCard(card)}
                      >
                        <div className="card-env-icon">
                          {unlocked
                            ? <div className="env-mini">✉</div>
                            : <div className="lock-mini">🔒</div>}
                        </div>
                        <div className="card-info">
                          {isToday && <span className="badge-now">DISPONÍVEL HOJE</span>}
                          <div className="card-title">{card.title}</div>
                          <div className="card-date">Para abrir em {card.unlockMonth}/{card.unlockDay}</div>
                        </div>
                        <div className="card-cta">
                          {unlocked ? (
                            <button
                              className="btn-abrir"
                              onClick={(e) => { e.stopPropagation(); setSelectedCard(card); }}
                            >Abrir agora</button>
                          ) : (
                            <span className="badge-locked">BLOQUEADA</span>
                          )}
                        </div>
                      </div>
                    );
                  })}

                  {/* Birthday card row */}
                  <div className={`card-row bday-row ${birthday ? "card-open" : "card-locked"}`}>
                    <div className="card-env-icon">{birthday ? "🎂" : "🔒"}</div>
                    <div className="card-info">
                      {birthday && <span className="badge-now">DISPONÍVEL HOJE</span>}
                      <div className="card-title">Dia do Aniversário ✨</div>
                      <div className="card-date">Para abrir em 6/18</div>
                    </div>
                    <div className="card-cta">
                      {birthday
                        ? <button className="btn-abrir">Abrir agora</button>
                        : <span className="badge-locked">BLOQUEADA</span>}
                    </div>
                  </div>
                </div>

                <p className="right-footer">
                  Cada carta guarda um pedacinho<br />do que sinto por você. &nbsp;♡
                </p>
              </>
            )}
          </div>
        </div>
      </div>

      {/* ── FILM STRIP ── */}
      <div className="filmstrip-bar">
        <PhotoStrip />
      </div>

      <CardModal card={selectedCard} onClose={() => setSelectedCard(null)} />
    </div>
  );
}
