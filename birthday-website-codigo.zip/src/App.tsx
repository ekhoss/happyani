import { useState } from "react";
import PasswordScreen from "./components/PasswordScreen";
import BirthdayPage from "./BirthdayPage";
import "./index.css";

export default function App() {
  // Check if already unlocked in this session
  const [unlocked, setUnlocked] = useState(
    () => sessionStorage.getItem("bday_unlocked") === "yes"
  );

  const handleUnlock = () => {
    sessionStorage.setItem("bday_unlocked", "yes");
    setUnlocked(true);
  };

  if (!unlocked) return <PasswordScreen onUnlock={handleUnlock} />;
  return <BirthdayPage />;
}
