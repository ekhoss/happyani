import { useState, useEffect } from "react";
import { ADVENT_GIFTS } from "../config";

export default function AdventCalendar() {
  const [opened, setOpened] = useState<Set<number>>(() => {
    try {
      const stored = localStorage.getItem("advent_opened");
      return stored ? new Set(JSON.parse(stored)) : new Set();
    } catch {
      return new Set();
    }
  });
  const [selected, setSelected] = useState<(typeof ADVENT_GIFTS)[0] | null>(null);

  const handleOpen = (gift: (typeof ADVENT_GIFTS)[0]) => {
    const next = new Set(opened);
    next.add(gift.id);
    setOpened(next);
    localStorage.setItem("advent_opened", JSON.stringify([...next]));
    setSelected(gift);
  };

  return (
    <div className="advent-wrapper">
      <h2 className="advent-title">🎂 Happy Birthday! Open your gifts!</h2>
      <div className="advent-grid">
        {ADVENT_GIFTS.map((gift) => {
          const isOpen = opened.has(gift.id);
          return (
            <button
              key={gift.id}
              className={`advent-box ${isOpen ? "advent-box-open" : ""}`}
              onClick={() => handleOpen(gift)}
            >
              {isOpen ? (
                <span className="advent-emoji">{gift.emoji}</span>
              ) : (
                <span className="advent-lock">🎁</span>
              )}
              <span className="advent-num">{gift.id}</span>
            </button>
          );
        })}
      </div>

      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal-card advent-modal" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setSelected(null)}>✕</button>
            <div className="advent-modal-emoji">{selected.emoji}</div>
            <h2 className="modal-title">{selected.title}</h2>
            {selected.image && (
              <img src={selected.image} alt="" className="modal-image" />
            )}
            <div className="modal-message">
              {selected.message.split("\n").map((line, i) => (
                <p key={i}>{line || <br />}</p>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
