import { useState } from "react";

interface Props { onUnlock: () => void; }

const SECRET = "cirice";

export default function PasswordScreen({ onUnlock }: Props) {
  const [input, setInput]   = useState("");
  const [error, setError]   = useState(false);
  const [shake, setShake]   = useState(false);
  const [opening, setOpening] = useState(false);

  const tryUnlock = () => {
    if (input.trim().toLowerCase() === SECRET) {
      setOpening(true);
      setTimeout(onUnlock, 900);
    } else {
      setError(true);
      setShake(true);
      setTimeout(() => setShake(false), 600);
      setTimeout(() => setError(false), 2200);
    }
  };

  return (
    <div className={`pw-screen ${opening ? "pw-opening" : ""}`}>
      {/* background bokeh dots */}
      {Array.from({ length: 18 }).map((_, i) => (
        <div key={i} className="bokeh" style={{
          left: `${Math.random() * 100}%`,
          top:  `${Math.random() * 100}%`,
          animationDelay: `${(i * 0.37) % 3}s`,
          width:  `${6 + (i % 5) * 4}px`,
          height: `${6 + (i % 5) * 4}px`,
        }} />
      ))}

      <div className={`pw-book ${shake ? "pw-shake" : ""}`}>
        {/* book cover decorations */}
        <div className="pw-corner pw-corner-tl">♥</div>
        <div className="pw-corner pw-corner-tr">♥</div>
        <div className="pw-corner pw-corner-bl">♥</div>
        <div className="pw-corner pw-corner-br">♥</div>

        <div className="pw-inner">
          <div className="pw-heart-deco">♡</div>
          <h1 className="pw-title">Para você</h1>
          <p className="pw-subtitle">
            Este caderno é só para quem eu amo.<br />
            Digite a senha para abrir ♡
          </p>

          <div className="pw-lock-icon">{error ? "✕" : "🔒"}</div>

          <input
            className={`pw-input ${error ? "pw-input-error" : ""}`}
            type="password"
            value={input}
            placeholder="senha secreta..."
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && tryUnlock()}
            autoFocus
          />

          {error && <p className="pw-error">Senha incorreta, tente novamente.</p>}

          <button className="pw-btn" onClick={tryUnlock}>
            Abrir o caderno ↗
          </button>

          <p className="pw-hint">Feito com ♡ pra você</p>
        </div>
      </div>
    </div>
  );
}
