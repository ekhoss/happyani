import { useEffect, useState } from "react";

interface CardModalProps {
  card: {
    title: string;
    message: string;
    image?: string;
  } | null;
  onClose: () => void;
}

export default function CardModal({ card, onClose }: CardModalProps) {
  const [phase, setPhase] = useState<"envelope" | "opening" | "letter">("envelope");

  // Reset animation phases when card changes
  useEffect(() => {
    if (!card) return;
    setPhase("envelope");
    const t1 = setTimeout(() => setPhase("opening"), 300);
    const t2 = setTimeout(() => setPhase("letter"), 1000);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [card]);

  useEffect(() => {
    if (!card) return;
    const handleKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [card, onClose]);

  if (!card) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-scene" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>✕</button>

        {/* ── Envelope animation ── */}
        <div className={`envelope-wrap ${phase === "opening" ? "env-opening" : ""} ${phase === "letter" ? "env-done" : ""}`}>
          <div className="env-back" />
          <div className="env-flap" />
          <div className="env-body">
            <div className="env-heart">♥</div>
          </div>
        </div>

        {/* ── Letter content (slides up) ── */}
        <div className={`letter-card ${phase === "letter" ? "letter-visible" : ""}`}>
          <div className="letter-top-deco">✉ &nbsp; {card.title} &nbsp; ✉</div>
          {card.image && (
            <img src={card.image} alt="" className="modal-image" />
          )}
          <div className="modal-message">
            {card.message.split("\n").map((line, i) => (
              <p key={i}>{line || <>&nbsp;</>}</p>
            ))}
          </div>
          <div className="letter-bottom-deco">♡ &nbsp; com amor &nbsp; ♡</div>
        </div>
      </div>
    </div>
  );
}
