import { useState, useRef, useEffect } from "react";
import { SONGS } from "../config";

export default function MusicPlayer() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  const song = SONGS[currentIndex];

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.src = song.src;
    if (isPlaying) {
      audio.play().catch(() => setIsPlaying(false));
    }
  }, [currentIndex]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.play().catch(() => setIsPlaying(false));
    } else {
      audio.pause();
    }
  }, [isPlaying]);

  const handleTimeUpdate = () => {
    const audio = audioRef.current;
    if (!audio) return;
    setCurrentTime(audio.currentTime);
    setDuration(audio.duration || 0);
  };

  const handleEnded = () => {
    const next = (currentIndex + 1) % SONGS.length;
    setCurrentIndex(next);
    setIsPlaying(true);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.currentTime = Number(e.target.value);
    setCurrentTime(audio.currentTime);
  };

  const fmt = (s: number) => {
    if (!isFinite(s)) return "0:00";
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, "0")}`;
  };

  const prev = () => {
    setCurrentIndex((currentIndex - 1 + SONGS.length) % SONGS.length);
    setIsPlaying(true);
  };

  const next = () => {
    setCurrentIndex((currentIndex + 1) % SONGS.length);
    setIsPlaying(true);
  };

  return (
    <div className="music-player">
      <audio
        ref={audioRef}
        src={song.src}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleTimeUpdate}
        onEnded={handleEnded}
      />

      <div className="player-song-info">
        <div className="player-cover">
          {song.cover ? (
            <img src={song.cover} alt={song.title} />
          ) : (
            <div className="player-cover-placeholder">♪</div>
          )}
        </div>
        <div className="player-meta">
          <div className="player-title">{song.title}</div>
          <div className="player-artist">{song.artist}</div>
        </div>
        <div className="player-heart">♥</div>
      </div>

      <div className="player-progress">
        <span className="player-time">{fmt(currentTime)}</span>
        <input
          type="range"
          min={0}
          max={duration || 100}
          value={currentTime}
          onChange={handleSeek}
          className="progress-bar"
        />
        <span className="player-time">{fmt(duration)}</span>
      </div>

      <div className="player-controls">
        <button className="ctrl-btn" onClick={prev}>⏮</button>
        <button className="ctrl-btn ctrl-play" onClick={() => setIsPlaying(!isPlaying)}>
          {isPlaying ? "⏸" : "▶"}
        </button>
        <button className="ctrl-btn" onClick={next}>⏭</button>
      </div>
    </div>
  );
}
