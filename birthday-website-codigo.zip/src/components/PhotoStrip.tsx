import { useState, useRef } from "react";
import { PHOTOS } from "../config";

export default function PhotoStrip() {
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [active, setActive] = useState(0);
  const stripRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: "left" | "right") => {
    const el = stripRef.current;
    if (!el) return;
    el.scrollBy({ left: dir === "left" ? -160 : 160, behavior: "smooth" });
  };

  return (
    <div className="photo-strip-wrapper">
      <button className="strip-arrow strip-arrow-left" onClick={() => scroll("left")}>❮</button>
      <div className="photo-strip" ref={stripRef}>
        {PHOTOS.map((src, i) => (
          <div
            key={i}
            className={`strip-thumb ${active === i ? "strip-thumb-active" : ""}`}
            onClick={() => { setActive(i); setLightbox(src); }}
          >
            <img src={src} alt={`Photo ${i + 1}`} />
          </div>
        ))}
      </div>
      <button className="strip-arrow strip-arrow-right" onClick={() => scroll("right")}>❯</button>

      {lightbox && (
        <div className="modal-overlay" onClick={() => setLightbox(null)}>
          <div className="lightbox" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setLightbox(null)}>✕</button>
            <img src={lightbox} alt="" />
            <div className="lightbox-nav">
              <button onClick={() => {
                const prev = (active - 1 + PHOTOS.length) % PHOTOS.length;
                setActive(prev);
                setLightbox(PHOTOS[prev]);
              }}>❮</button>
              <span>{active + 1} / {PHOTOS.length}</span>
              <button onClick={() => {
                const next = (active + 1) % PHOTOS.length;
                setActive(next);
                setLightbox(PHOTOS[next]);
              }}>❯</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
