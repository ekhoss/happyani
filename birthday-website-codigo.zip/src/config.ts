// ============================================================
//  BIRTHDAY WEBSITE CONFIG — Edit everything here!
// ============================================================

/** Name shown at the top of the website */
export const BIRTHDAY_PERSON = "Name Here";

/** Subtitle / tagline shown under the title */
export const TAGLINE = "Every memory with you is my favorite song.";

/** Footer credit */
export const FOOTER_TEXT = "Made with love for you ♡";

// ============================================================
//  CARDS — one per day (June 15–20)
//  unlockMonth: 6 = June. unlockDay: day of month.
//  Add your personal message in the `message` field.
// ============================================================
export const CARDS = [
  {
    id: 1,
    title: "Card 01",
    unlockMonth: 6,
    unlockDay: 15,
    label: "Open on June 15",
    message: "Write your heartfelt message here for June 15th...\n\nYou can use multiple paragraphs.",
    // image: "/photos/card1.jpg",  // optional: put image in public/photos/
  },
  {
    id: 2,
    title: "Card 02",
    unlockMonth: 6,
    unlockDay: 16,
    label: "Open on June 16",
    message: "Write your heartfelt message here for June 16th...",
    // image: "/photos/card2.jpg",
  },
  {
    id: 3,
    title: "Card 03",
    unlockMonth: 6,
    unlockDay: 17,
    label: "Open on June 17",
    message: "Write your heartfelt message here for June 17th...",
    // image: "/photos/card3.jpg",
  },
  // June 18 = BIRTHDAY — handled as Advent Calendar below
  {
    id: 5,
    title: "Card 05",
    unlockMonth: 6,
    unlockDay: 19,
    label: "Open on June 19",
    message: "Write your heartfelt message here for June 19th...",
    // image: "/photos/card5.jpg",
  },
  {
    id: 6,
    title: "Card 06",
    unlockMonth: 6,
    unlockDay: 20,
    label: "Open on June 20",
    message: "Write your heartfelt message here for June 20th...",
    // image: "/photos/card6.jpg",
  },
];

// ============================================================
//  ADVENT CALENDAR — shown on June 18 (the birthday!)
//  Add as many gifts as you want.
// ============================================================
export const BIRTHDAY_DATE = { month: 6, day: 18 };

export const ADVENT_GIFTS = [
  {
    id: 1,
    emoji: "🎂",
    title: "Happy Birthday!",
    message: "Today is your special day! Write something wonderful here...",
    // image: "/photos/gift1.jpg",
  },
  {
    id: 2,
    emoji: "🎁",
    title: "A Little Surprise",
    message: "Surprise number two! Write your message here...",
    // image: "/photos/gift2.jpg",
  },
  {
    id: 3,
    emoji: "💌",
    title: "A Letter for You",
    message: "Dear [Name], write your heartfelt letter here...",
    // image: "/photos/gift3.jpg",
  },
  {
    id: 4,
    emoji: "✨",
    title: "A Memory",
    message: "Remember when... write a special memory here.",
    // image: "/photos/gift4.jpg",
  },
  {
    id: 5,
    emoji: "🌸",
    title: "Something Beautiful",
    message: "Write something beautiful here...",
    // image: "/photos/gift5.jpg",
  },
  {
    id: 6,
    emoji: "🎶",
    title: "Our Song",
    message: "This song always makes me think of you...",
    // image: "/photos/gift6.jpg",
  },
];

// ============================================================
//  MUSIC PLAYLIST
//  Put your MP3 files in: public/music/
//  Example: public/music/lover.mp3  → src: "/music/lover.mp3"
//  Or use a full URL: src: "https://example.com/song.mp3"
// ============================================================
export const SONGS = [
  {
    title: "Song Title 1",
    artist: "Artist Name",
    src: "/music/song1.mp3",
    // cover: "/covers/song1.jpg",  // optional album art
  },
  {
    title: "Song Title 2",
    artist: "Artist Name",
    src: "/music/song2.mp3",
    // cover: "/covers/song2.jpg",
  },
  {
    title: "Song Title 3",
    artist: "Artist Name",
    src: "/music/song3.mp3",
  },
];

// ============================================================
//  PHOTOS — shown in the strip at the bottom
//  Put your photos in: public/photos/
//  Example: public/photos/photo1.jpg → "/photos/photo1.jpg"
// ============================================================
export const PHOTOS = [
  "/photos/photo1.jpg",
  "/photos/photo2.jpg",
  "/photos/photo3.jpg",
  "/photos/photo4.jpg",
  "/photos/photo5.jpg",
  "/photos/photo6.jpg",
  "/photos/photo7.jpg",
  "/photos/photo8.jpg",
];

// ============================================================
//  MAIN SCRAPBOOK PHOTO — shown large in the center-left
//  Put your main photo in: public/photos/main.jpg
// ============================================================
export const MAIN_PHOTO = "/photos/main.jpg";

// ============================================================
//  SCRAPBOOK QUOTES — shown on the left panel
// ============================================================
export const QUOTES = [
  "From the moment I met you, life gained color and purpose.",
  "If I said I love you, it's because I want to love you forever.",
  "You and I, always. My favorite place.",
];
